// Pinned upstream model, first-feasible DFS selection; no upstream source edits.
#include <fstream>
#include <sstream>
#include "aux/MajorTonality.hpp"
#include "aux/MidiFileGeneration.hpp"
#include "diatony/FourVoiceTexture.hpp"

int main(int argc, char** argv) {
    if (argc != 6) return 2;
    int tonic = std::stoi(argv[1]), budget = std::stoi(argv[2]);
    if (tonic < 0 || tonic > 11 || budget < 1) return 2;
    std::vector<int> degrees;
    std::istringstream input(argv[3]);
    std::string token;
    while (std::getline(input, token, ',')) {
        int degree = std::stoi(token);
        if (degree < 0 || degree > 6) return 2;
        degrees.push_back(degree);
    }
    if (degrees.size() < 3 || degrees.size() > 6) return 2;
    int n = degrees.size();
    MajorTonality tonality(tonic);
    std::vector<int> qualities;
    for (int degree : degrees) qualities.push_back(tonality.get_chord_quality(degree));
    TonalProgressionParameters section(0, n, 0, n - 1, &tonality, degrees, qualities, std::vector<int>(n, 0));
    FourVoiceTextureParameters params(n, 1, {&section}, {});
    Gecode::Search::Options options;
    options.threads = 1;
    options.stop = Gecode::Search::Stop::time(budget);
    auto root = new FourVoiceTexture(&params);
    Gecode::DFS<FourVoiceTexture> engine(root, options);
    delete root;
    auto solution = engine.next();
    if (!solution) return engine.stopped() ? 4 : 3;
    int* values = solution->return_solution();
    std::ofstream score(argv[4]);
    score << "VOICE_ROWS_B_T_A_S\n";
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < 4; ++j) score << values[4*i+j] << (j == 3 ? '\n' : ' ');
    }
    writeSolToMIDIFile(n, argv[5], solution);
    score.close();
    delete[] values;
    delete solution;
    return score ? 0 : 5;
}
